// pages/loginPage.ts
import { Page, Locator } from "@playwright/test";
import { allure } from "allure-playwright";

export class LoginPage {
  readonly page: Page;
  readonly usernameInput: Locator;
  readonly passwordInput: Locator;
  readonly loginButton: Locator;

  constructor(page: Page) {
    this.page = page;

    this.usernameInput = page.getByPlaceholder("Username");
    this.passwordInput = page.getByPlaceholder("Password");
    this.loginButton = page.getByRole("button", { name: "Login" });
  }

  async enterUsername(username: string) {
    await allure.step(`Enter username: ${username}`, async () => {
      await this.usernameInput.fill(username);
    });
  }

  async enterPassword(password: string) {
    await allure.step(`Enter password`, async () => {
      await this.passwordInput.fill(password);
    });
  }

  async clickLogin() {
    await allure.step(`Click login button`, async () => {
      await this.loginButton.click();
    });
  }

  async login(username: string, password: string) {
    await allure.step(`Perform login with username=${username}`, async () => {
      await this.enterUsername(username);
      await this.enterPassword(password);
      await this.clickLogin();
    });
  }
}
