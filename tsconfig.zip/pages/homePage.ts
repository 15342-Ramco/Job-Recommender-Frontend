// pages/homePage.ts
import { Page, Locator, expect } from "@playwright/test";
import { allure } from "allure-playwright";

export class HomePage {
  readonly page: Page;
  readonly upgradeButton: Locator;
  readonly performanceLink: Locator;
  readonly dashboardLink: Locator;

  constructor(page: Page) {
    this.page = page;

    this.upgradeButton = page.getByRole("button", { name: "Upgrade" });
    this.performanceLink = page.getByRole("link", { name: "Performance" });
    this.dashboardLink = page.getByRole("link", { name: "Dashboard" });
  }

  async isUpgradeButtonVisible() {
    await allure.step("Validate Upgrade button is visible", async () => {
      await expect(this.upgradeButton).toBeVisible();
    });
  }

  async clickPerformance() {
    await allure.step("Click Performance link", async () => {
      await this.performanceLink.click();
    });
  }

  async clickDashboard() {
    await allure.step("Click Dashboard link", async () => {
      await this.dashboardLink.click();
    });
  }
}
