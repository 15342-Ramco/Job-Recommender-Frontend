import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './tests',
  reporter: [
    ["list"],
    ["allure-playwright"]
  ],
  use: {
    headless: false,
    video: "retain-on-failure",
    screenshot: "only-on-failure",
    trace: "on-first-retry"
  }
});
