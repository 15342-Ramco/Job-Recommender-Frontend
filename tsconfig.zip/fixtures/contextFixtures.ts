import { test as base, Browser, Page, BrowserContext } from "@playwright/test";
import { allure } from "allure-playwright";
import * as fs from "fs";
import * as path from "path";

const ROOT_DIR = path.resolve(__dirname, "..");

// -----------------------------
// Fixtures type extension
// -----------------------------
type ContextFixtures = {
  page: Page;
  context: BrowserContext;
  browser: Browser;
  testFolder: string;
  getJsonData: (filePath: string) => any;
};

export const test = base.extend<ContextFixtures>({
  // Data fixture - read JSON test data
  getJsonData: async ({}, use) => {
    const reader = async (filePath: string) => {
      const raw = fs.readFileSync(filePath, "utf-8");
      const data = JSON.parse(raw);
      return data;
    };
    await use(reader);
  },

  // Create test folder first
  testFolder: async ({}, use, testInfo) => {
    const testName = testInfo.title.replace(/[\/\s]/g, "_");
    const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
    const testFolder = path.join(ROOT_DIR, "artifacts", `${testName}_${timestamp}`);
    fs.mkdirSync(testFolder, { recursive: true });
    console.log(`\n📁 Creating test folder: ${testFolder}`);
    await use(testFolder);
  },

  // SESSION-SCOPE BROWSER
  // -----------------------------
  browser: [
    async ({ playwright }, use) => {
      const browser = await playwright.chromium.launch({ headless: false });
      await use(browser);
      await browser.close();
    },
    { scope: "worker" }
  ],

  // TEST-SCOPE CONTEXT + PAGE
  // -----------------------------
  context: async ({ browser, testFolder }, use) => {
    const context = await browser.newContext({
      recordVideo: { dir: testFolder }
    });

    await context.tracing.start({
      screenshots: true,
      snapshots: true,
      sources: true
    });

    await use(context);

    // Close all pages first (finalizes video)
    const pages = context.pages();
    for (const page of pages) {
      await page.close();
    }

    // Wait a moment for video to finalize
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Attach video from recorded files
    try {
      const videoFiles = fs.readdirSync(testFolder).filter(f => f.endsWith(".webm"));
      for (const videoFile of videoFiles) {
        const videoPath = path.join(testFolder, videoFile);
        if (fs.existsSync(videoPath)) {
          console.log(`✅ Attaching video: ${videoPath}`);
          allure.attachment("Execution Video", fs.readFileSync(videoPath), "video/webm");
        }
      }
    } catch (e) {
      console.error("Error attaching video:", e);
    }

    // Save TRACE
    const tracePath = path.join(testFolder, "trace.zip");
    try {
      await context.tracing.stop({ path: tracePath });
      if (fs.existsSync(tracePath)) {
        console.log(`✅ Attaching trace: ${tracePath}`);
        allure.attachment("Playwright Trace", fs.readFileSync(tracePath), "application/zip");
      }
    } catch (e) {
      console.error("Error attaching trace:", e);
    }

    // Close context at end
    await context.close();
  },

  // PAGE FIXTURE
  // -----------------------------
  page: async ({ context, testFolder }, use) => {
    const page = await context.newPage();

    await use(page);

    // Attach screenshot
    const screenshotPath = path.join(testFolder, "screenshot.png");
    try {
      await page.screenshot({ path: screenshotPath, fullPage: true });
      if (fs.existsSync(screenshotPath)) {
        console.log(`✅ Attaching screenshot: ${screenshotPath}`);
        allure.attachment("Screenshot", fs.readFileSync(screenshotPath), "image/png");
      }
    } catch (e) {
      console.error("Error attaching screenshot:", e);
    }

    // Attach HTML snapshot
    const htmlPath = path.join(testFolder, "page.html");
    try {
      const html = await page.content();
      fs.writeFileSync(htmlPath, html);
      if (fs.existsSync(htmlPath)) {
        console.log(`✅ Attaching HTML: ${htmlPath}`);
        allure.attachment("HTML Snapshot", fs.readFileSync(htmlPath), "text/html");
      }
    } catch (e) {
      console.error("Error attaching HTML snapshot:", e);
    }
  }
});

export const expect = test.expect;
