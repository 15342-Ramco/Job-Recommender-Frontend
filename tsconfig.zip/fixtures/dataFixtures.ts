import { test as base } from "@playwright/test";
import * as fs from "fs";

type TestDataFixture = {
  getJsonData: (filePath: string) => any;
};

export const test = base.extend<TestDataFixture>({
  getJsonData: async ({}, use) => {
    const reader = async (filePath: string) => {
      const raw = fs.readFileSync(filePath, "utf-8");
      const data = JSON.parse(raw);
      return data;
    };
    await use(reader);
  }
});

export const expect = test.expect;
