import { test, expect } from "../fixtures/contextFixtures";
import {LoginPage} from "../pages/loginPage";
import { allure } from "allure-playwright";

test("Login using JSON data", async ({ page, getJsonData }) => {
  // Add Allure annotations
  allure.epic("Authentication");
  allure.feature("Login");
  allure.story("User login with credentials");
  allure.severity("critical");
  allure.tag("smoke");
  allure.tag("authentication");
  allure.label("testType", "E2E");
  
  const data = await getJsonData("testdata/login.json");
  const login = new LoginPage(page);

  await allure.step("Navigate to login page", async () => {
    await page.goto(data.url);
  });

  await allure.step("Enter username", async () => {
    await login.enterUsername(data.username);
  });

  await allure.step("Enter password", async () => {
    await login.enterPassword(data.password);
  });

  await allure.step("Click login button", async () => {
    await login.clickLogin();
  });

  await allure.step("Verify login success", async () => {
    // Add your assertion here
    expect(page).toBeDefined();
  });
});
